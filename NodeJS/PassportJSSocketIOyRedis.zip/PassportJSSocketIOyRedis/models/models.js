var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/prueba1');

module.exports = mongoose;